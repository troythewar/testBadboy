window.external.Script.References.addProvider("Word Heading Importer", "wordref");
